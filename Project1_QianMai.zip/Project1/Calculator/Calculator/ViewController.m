//
//  ViewController.m
//  Calculator
//
//  Created by Qian Mai on 2/1/15.
//  Copyright (c) 2015 Qian Mai. All rights reserved.
//

#import "ViewController.h"
#import "CalculatorBrain.h"

@interface ViewController()
@property (nonatomic) BOOL userIsInTheMiddleOfEnteringANumber;
@property (nonatomic, strong) CalculatorBrain *brain;
@property (nonatomic) BOOL settingFoo;
@property (nonatomic) NSMutableArray *operationArray;
@property (nonatomic) NSString *fooExpression;
@end

@implementation ViewController

@synthesize display;
@synthesize userIsInTheMiddleOfEnteringANumber;
@synthesize brain = _brain;
@synthesize settingFoo;
@synthesize operationArray;
@synthesize fooExpression;

//Calculator brain initializaiotn
- (CalculatorBrain *)brain
{
    if (!_brain) {
        _brain = [[CalculatorBrain alloc] init];
    }
    return _brain;
}

//digit press action
- (IBAction)digitPressed:(UIButton *)sender {
    NSString *digit = [sender currentTitle];
    if (self.userIsInTheMiddleOfEnteringANumber){
        if ([digit isEqualToString:@"."]) {
            //Only allow one dot
            if ([self.display.text rangeOfString:@"."].location == NSNotFound){
                self.display.text = [self.display.text stringByAppendingString:digit];
            }
        } else {
            self.display.text = [self.display.text stringByAppendingString:digit];
        }
    } else {
        //Automatically fill "0" if press "." directly
        if ([digit isEqualToString:@"."]) {
            self.display.text = @"0.";
        } else {
            self.display.text = digit;
        }
        self.userIsInTheMiddleOfEnteringANumber = YES;
    }
    
    if (([self.sent.text rangeOfString:@"="].location != NSNotFound) && (!self.settingFoo)) {
        self.sent.text = @"";
    }
}

//enter button action
- (IBAction)enterPressed {
    if (!self.settingFoo) {
        //Calculator Brain
        [self.brain pushOperand:[self.display.text doubleValue]];
        
        //Sent lable display
        self.sent.text = [self.sent.text stringByAppendingString:@" "];
        self.sent.text = [self.sent.text stringByAppendingString:self.display.text];
        self.userIsInTheMiddleOfEnteringANumber = NO;
    } else {
        [self.brain saveVariableValue:self.display.text];
        self.sent.text = [self.sent.text stringByAppendingString:self.display.text];
        if ((![[self.brain getX] isEqualToString:@""]) && [[self.brain getY] isEqualToString:@""]) {
            self.display.text = @"Press y";
        } else if ((![[self.brain getY] isEqualToString:@""]) && [[self.brain getX] isEqualToString:@""]){
            self.display.text = @"Press x";
        } else {
            self.display.text = @"Press foo";
        }
        
    }
    
}

//operation action
- (IBAction)operationPressed:(id)sender {
    if (!self.settingFoo) {
        NSString *operation = [sender currentTitle];
        
        //Calculator Brain
        if (self.userIsInTheMiddleOfEnteringANumber) {
            [self enterPressed];
        }
        
        if (![operation isEqualToString:@"C"]) {
            //Update the description of program for common sence
            self.sent.text = [self.brain descriptionOfProgram : self.sent.text second: operation];
        }
        
        [self.sent.text stringByReplacingOccurrencesOfString:@" =" withString:@""];
        
        double result = [self.brain performOperation:operation];
        self.sent.text = [self.sent.text stringByAppendingString:@" ="];
        self.display.text = [NSString stringWithFormat:@"%g", result];
        
        //Reset
        if ([operation isEqualToString:@"C"]) {
            self.sent.text = @"";
            self.userIsInTheMiddleOfEnteringANumber = NO;
            [self.brain resetVariables];
        }
    } else {
        self.settingFoo = NO;
        [self.brain performOperation:@"C"];
    }
}

//backspace action
- (IBAction)backspacePressed {
    //Keep 0 if only one digit last
    if ([self.display.text length] == 1) {
        self.display.text = @"0";
        self.userIsInTheMiddleOfEnteringANumber = NO;
    //Keep 0 if only one negtive digit last
    } else if ([self.display.text length] == 2 && [self.display.text characterAtIndex:0] == '-') {
        self.display.text = @"0";
        self.userIsInTheMiddleOfEnteringANumber = NO;
    //Delete last digit
    } else {
        self.display.text = [self.display.text substringToIndex:[self.display.text length] - 1];
    }
}

//+/- sign action
- (IBAction)signPressed {
    if ([self.display.text characterAtIndex:0] == '-') {
        self.display.text = [self.display.text substringFromIndex:1];
    } else if (![self.display.text isEqualToString:@"0"]){
        self.display.text = [@"-" stringByAppendingString:self.display.text];
    }
}

//Variable press action
- (IBAction)variablePressed:(id)sender {
    self.settingFoo = YES;
    NSString *variable = [sender currentTitle];
    [self.brain selectVariable:variable];
    self.sent.text = [@"(Input value then press Enter) " stringByAppendingString:variable];
    self.sent.text = [self.sent.text stringByAppendingString:@"="];
    userIsInTheMiddleOfEnteringANumber = NO;
    self.display.text = @"0";
}

//Use foo
- (IBAction)fooPressed {
    //If x and y has been set values
    if ((![[self.brain getX] isEqualToString:@""]) && (![[self.brain getY] isEqualToString:@""] && self.settingFoo)) {
        //Clear operationStack
//        [self.brain performOperation:@"C"];
        self.sent.text = [@"foo = x - y = " stringByAppendingString:self.brain.getX];
        self.sent.text = [self.sent.text stringByAppendingString:@" - "];
        self.sent.text = [self.sent.text stringByAppendingString:self.brain.getY];
        self.sent.text = [self.sent.text stringByAppendingString:@" ="];
        
        //x-y input order: x, y, -
        [self.brain pushOperand:[[self.brain getX] doubleValue]];
        [self.brain pushOperand:[[self.brain getY] doubleValue]];
        double result = [self.brain performOperation:@"-"];
        
        self.display.text = [NSString stringWithFormat:@"%g", result];
        //Reset x and y value
        [self.brain resetVariables];
        userIsInTheMiddleOfEnteringANumber = NO;
        self.settingFoo = NO;
    } else {
        [self.brain resetVariables];
        self.sent.text = @"";
        self.display.text = @"Press x to input value";
        userIsInTheMiddleOfEnteringANumber = NO;
    }
    
    
}
@end
