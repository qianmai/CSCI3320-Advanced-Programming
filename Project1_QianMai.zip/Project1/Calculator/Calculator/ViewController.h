//
//  ViewController.h
//  Calculator
//
//  Created by Qian Mai on 2/1/15.
//  Copyright (c) 2015 Qian Mai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *display;
@property (weak, nonatomic) IBOutlet UILabel *sent;

@end

