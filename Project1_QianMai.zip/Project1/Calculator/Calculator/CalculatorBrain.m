//
//  CalculatorBrain.m
//  Calculator
//
//  Created by Qian Mai on 2/1/15.
//  Copyright (c) 2015 Qian Mai. All rights reserved.
//

#import "CalculatorBrain.h"

@interface CalculatorBrain()

@property (nonatomic, strong) NSMutableArray *programStack;
@property (nonatomic) NSArray *numArray;
@property (nonatomic) NSMutableArray *expressionArray;
@property (nonatomic) NSString *expressionString;
@property (nonatomic) NSString *fooExpression;
@property (nonatomic) NSString *xValue;
@property (nonatomic) NSString *yValue;
@property (nonatomic) NSString *waitingInputVariable;
@property (nonatomic) NSMutableArray *fooArray;
@end

@implementation CalculatorBrain

@synthesize programStack = _programStack;
@synthesize numArray;
@synthesize expressionArray;
@synthesize expressionString;
@synthesize fooExpression;
@synthesize xValue;
@synthesize yValue;
@synthesize waitingInputVariable;
@synthesize fooArray;

//operand stack initialization
- (NSMutableArray *)programStack
{
    if (!_programStack) {
        _programStack = [[NSMutableArray alloc] init];
    }
    return _programStack;
}

//run program
- (id)program{
    return [self.programStack copy];
}

//push operand
- (void)pushOperand:(double)operand
{
    [ self.programStack addObject:[NSNumber numberWithDouble:operand]];
}

////Pop operand
//- (double)popOperand
//{
//    NSNumber *operandObject = [self.programStack lastObject];
//    if (operandObject)
//    {
//        [self.programStack removeLastObject];
//    }
//    return [operandObject doubleValue];
//}

- (double)performOperation:(NSString *)operation
{
    [self.programStack addObject:operation];
    return [[self class] runProgram:self.program];
}

//Perform operation calculation
//- (double)performOperation:(NSString *)operation {
+ (double)popOperandOffProgramStack:(NSMutableArray *)stack {
    double result = 0;
    id topOfStack = [stack lastObject];
    
    if (topOfStack) {
        [stack removeLastObject];
    }
    
    if ([topOfStack isKindOfClass:[NSNumber class]]) {
        result = [topOfStack doubleValue];
    } else if ([topOfStack isKindOfClass:[NSString class]]) {
        NSString *operation = topOfStack;
        
        //perform the operation here, store answer in result
        if ([operation isEqualToString:@"+"]) {
            result = [self popOperandOffProgramStack:stack] + [self popOperandOffProgramStack:stack];
        } else if ([@"*" isEqualToString:operation]) {
            result = [self popOperandOffProgramStack:stack] * [self popOperandOffProgramStack:stack];
        } else if ([operation isEqualToString:@"-"]) {
            double subtrahend = [self popOperandOffProgramStack:stack];
            result = [self popOperandOffProgramStack:stack] - subtrahend;
        } else if ([operation isEqualToString:@"/"]) {
            double divisor = [self popOperandOffProgramStack:stack];
            if (divisor) {
                result = [self popOperandOffProgramStack:stack] / divisor;
            }
        } else if ([operation isEqualToString:@"sin"]) {
            result = sin([self popOperandOffProgramStack:stack]);
        } else if ([operation isEqualToString:@"cos"]) {
            result = cos([self popOperandOffProgramStack:stack]);
        } else if ([operation isEqualToString:@"sqrt"]) {
            result = sqrt([self popOperandOffProgramStack:stack]);
        } else if ([operation isEqualToString:@"π"]) {
            result = M_PI;
        } else if ([operation isEqualToString:@"C"]) {
            [stack removeAllObjects];
        }
    }
    return result;
}

+ (double)runProgram:(id)program {
    NSMutableArray *stack;
    if ([program isKindOfClass:[NSArray class] ]) {
        stack = [program mutableCopy];
    }
    return [self popOperandOffProgramStack:stack];
}

//Display the passed program in a more userfriendly manner
- (NSString *)descriptionOfProgram:(NSString *)currentString second:(NSString *)operation
{
    //Split String into an Array
    //Delete "="
    currentString = [currentString stringByReplacingOccurrencesOfString:@"=" withString:@""];
    //Trim
    NSString *trimmedStr = [currentString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    expressionArray = [[trimmedStr componentsSeparatedByString:@" "] mutableCopy];
    NSScanner *scanner;
    BOOL isNumeric;
    //Add current operation
    if ([expressionArray count] > 1) {
        for (int i = 0; i <= [expressionArray count] - 2; i++) {
            
            scanner = [NSScanner scannerWithString:[expressionArray objectAtIndex:i]];
            isNumeric = [scanner scanInteger:NULL] && [scanner isAtEnd];
            
            //Check element is numeric or variable
            if (!(isNumeric || [[expressionArray objectAtIndex:i] isEqualToString:@"x"] || [[expressionArray objectAtIndex:i] isEqualToString:@"y"])) {
                if ([[expressionArray objectAtIndex:i] isEqualToString:@"("]) {
                    //Add operation
                    [expressionArray insertObject:operation atIndex:i];
                    if (i != 1 && ([operation isEqualToString:@"+"] || [operation isEqualToString:@"-"])) {
                        ////Add parentheses
                        [expressionArray insertObject:@"(" atIndex:(i-1)];
                        [expressionArray addObject:@")"];
                    }
                } else if ([[expressionArray objectAtIndex:i] isEqualToString:@"sin"] || [[expressionArray objectAtIndex:i] isEqualToString:@"cos"] || [[expressionArray objectAtIndex:i] isEqualToString:@"sqrt"]) {
                    [expressionArray insertObject:operation atIndex:i];
                    if ([operation isEqualToString:@"sin"] || [operation isEqualToString:@"cos"] || [operation isEqualToString:@"sqrt"]) {
                        [expressionArray insertObject:@"(" atIndex:(i+1)];
                        [expressionArray addObject:@")"];
                    } else {
                        if ([operation isEqualToString:@"+"] || [operation isEqualToString:@"-"]) {
                            [expressionArray insertObject:@"(" atIndex:(i-1)];
                            [expressionArray addObject:@")"];
                        }
                    }
                } else {
                    //Add operation
                    [expressionArray insertObject:operation atIndex:(i-1)];
                    if ([operation isEqualToString:@"sin"] || [operation isEqualToString:@"cos"] || [operation isEqualToString:@"sqrt"]) {
                        if ([[expressionArray objectAtIndex:(i+1)] isEqualToString:@"*"] || [[expressionArray objectAtIndex:(i+1)] isEqualToString:@"/"]) {
                            [expressionArray insertObject:@"(" atIndex:i];
                            [expressionArray addObject:@")"];
                        }
                    } else {
                        if (i != 2 && ([operation isEqualToString:@"+"] || [operation isEqualToString:@"-"])) {
                            //Add parentheses
                            [expressionArray insertObject:@"(" atIndex:(i-2)];
                            [expressionArray addObject:@")"];
                        }
                        if ([operation isEqualToString:@"/"]) {
                            //Add parentheses
                            [expressionArray insertObject:@"(" atIndex:i];
                            [expressionArray addObject:@")"];
                        }
                    }
                }
                
                break;
            }
            
            if (i == [expressionArray count] - 2) {
                //Add operation
                [expressionArray insertObject:operation atIndex:(i+1)];
                //Add parentheses
                if (i != 0 && ([operation isEqualToString:@"+"] || [operation isEqualToString:@"-"])) {
                    [expressionArray insertObject:@"(" atIndex:i];
                    [expressionArray addObject:@")"];
                } else if ([operation isEqualToString:@"sin"] || [operation isEqualToString:@"cos"] || [operation isEqualToString:@"sqrt"]) {
                    [expressionArray insertObject:@"(" atIndex:(i+2)];
                    [expressionArray addObject:@")"];
                }
                break;
            }
        }
    } else if ([operation isEqualToString:@"sin"] || [operation isEqualToString:@"cos"] || [operation isEqualToString:@"sqrt"]) {
        [expressionArray insertObject:@"(" atIndex:0];
        [expressionArray insertObject:operation atIndex:0];
        [expressionArray addObject:@")"];
//    } else if ([operation isEqualToString:@"π"]) {
//        [expressionArray insertObject:operation atIndex:0];
    }
    
    //Copy expressionArray to fooArray
    
    expressionString = [expressionArray componentsJoinedByString:@" "];
    return expressionString;
}

//Check a string contains operation or not
- (BOOL)containsOperation:(NSString *)currentString {
    NSString *trimmedStr = [currentString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSArray *elementArray = [trimmedStr componentsSeparatedByString:@" "];
    BOOL hasOperation = NO;
    NSScanner *scanner;
    BOOL isNumeric;
    for (NSString *str in elementArray) {
        scanner = [NSScanner scannerWithString:str];
        isNumeric = [scanner scanInteger:NULL] && [scanner isAtEnd];
        if (!isNumeric) {
            hasOperation = YES;
        }
    }
    return hasOperation;
}

//Save foo VariableValue
- (void)selectVariable:(NSString *)variable {
    self.yValue = @"";
    self.waitingInputVariable = variable;
}

//Save foo variable value
- (void)saveVariableValue:(NSString *)value{
    if ([self.waitingInputVariable isEqualToString:@"x"]) {
        self.xValue = value;
    } else if ([self.waitingInputVariable isEqualToString:@"y"]){
        self.yValue = value;
    }
}

//Get x value
- (NSString *)getX {
    return self.xValue;
}

//Get y value
- (NSString *)getY {
    return self.yValue;
}

//Reset x and y value
-(void)resetVariables {
    self.xValue = @"";
    self.yValue = @"";
}
@end
